<link rel="stylesheet" href="../css/style.css">
<?php
    include ("../include/header.php");
?>

<div class="container">
    <h2>Super Admin Login form</h2>
  <form action="/action_page.php">
    <div class="row">
      <div class="col-25">
        <label for="email">Email_Id</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="emailid" placeholder="Your email..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="pass">Password</label>
      </div>
      <div class="col-75">
        <input type="text" id="pass" name="password" placeholder="Your password..">
      </div>
    </div><br>  
        <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>

<?php
    include ("../include/footer.php");
?>
