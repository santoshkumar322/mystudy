<!DOCTYPE html>
<html lang="en">
<head>
<title>User MAnagement System</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
  <h2>Super Admin Dashboard</h2>
</header>
<section>
  <nav>
    <ul>
      <li><a href="add-new-user.php">Add New Users</a></li>
      <li><a href="delete-user-details.php">Delete User</a></li>
      <li><a href="show-user-details.php">show User Details</a></li>
      <li><a href="update-user-details.php">Update User Details</a></li>
    </ul>
  </nav>

  <article>
  <h1>This website works for User Management System</h1>
  <p>I developed User Management System with the roles  of Admin, Super Admin & User on this website. I shall give permission according to requirement.</p>
    <p><b>Super Admin: </b>Super Admin has full Access of Add, Edit, Delete users. (registration not required)</p>
    <p><b>Admin: </b>Admin has access of Add and Delete users. (registration not required)</p>
    <p><b>User: </b>User can update his profile details. (registration required + admin approval)</p>
  </article>
</section>

<footer>
<p>@ 2023 | Created by Santosh Kumar <span>(Click here to go <a href="index.php">Home</a> )</span></p>
</footer>

</body>
</html>
