<section>
  <nav>
    <ul>
      <li><a href="#">User</a></li>
      <li><a href="#">Admin</a></li>
      <li><a href="#">Super User</a></li>
    </ul>
  </nav>
</section>