
<footer>
  <p>@ 2023 | Created by Santosh Kumar <span>(Click here to go <a href="../index.php">Home</a> )</span></p>
</footer>

</body>
</html>