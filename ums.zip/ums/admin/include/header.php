<!DOCTYPE html>
<html lang="en">
<head>
<title>User MAnagement System</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<header>
  <h2>Admin Dashboard</h2>
</header>


