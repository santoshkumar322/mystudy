<?php
include_once 'db.php';
if(isset($_POST['save']))
{	 
	 $first_name = $_POST['first_name'];
	 $last_name = $_POST['last_name'];
	 $city_name = $_POST['city_name'];
	 $email = $_POST['email'];
	 $sql = "INSERT INTO employee (first_name,last_name,city_name,email)
	 VALUES ('$first_name','$last_name','$city_name','$email')";
	 if (mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>


<link rel="stylesheet" href="../css/style.css">

<div class="container">
  <form action="/action_page.php">
    <div class="row">
      <div class="col-25">
        <label for="fname">First Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" name="firstname" placeholder="Your name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="lname" name="lastname" placeholder="Your last name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="designation">Designation</label>
      </div>
      <div class="col-75">
        <input type="text" id="designation" name="Designation" placeholder="Your designation..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="dob">Date-of-birth</label>
      </div>
      <div class="col-75">
        <input type="date" id="dob" name="date-of-birth" placeholder="Your date-of-birth..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="doj">date-of-joining</label>
      </div>
      <div class="col-75">
        <input type="date" id="doj" name="date-of-joining" placeholder="Your date-of-joining..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="blood">Blood Group</label>
      </div>
      <div class="col-75">
        <input type="text" id="blood" name="blood-group" placeholder="Your blood-group..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="Email" placeholder="Your email..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="mnumber">Mobile No.</label>
      </div>
      <div class="col-75">
        <input type="text" id="mnumber" name="mobile-no" placeholder="Your mobile No..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="address">Address</label>
      </div>
      <div class="col-75">
        <input type="text" id="address" name="Address" placeholder="Your address..">
      </div>
    </div>
    <div class="row">
      <input type="submit" name="save" value="Submit">
    </div>
  </form>
</div>


