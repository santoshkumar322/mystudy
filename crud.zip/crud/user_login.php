<html>
<head>
<?php	

session_start(); 
 //header("location: user_form.php");

//echo "<script>alert('Logged Out Admin');</script>";

 //header("location: user_form.php");
 
 ?>
<body>
<style>
h1{
	color:darkblue;
}
  input[type=submit] {
    background-color: #04AA6D;
	width:80%;
    color: white;
    padding: 15px 20px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    float:center;
  }
  
  input[type=login]:hover {
    background-color: #45a049;
  }
form{

	border-radius:140px;
	width: 30%;
	margin:100px auto;
	background-color: #ccc;
	padding: 25px;

}
  input[type=text]{
    width: 80%;
    padding: 15px;
    border: 2px solid #ccc;
    border-radius: 10px;
    resize: vertical;
	
  }
  input[type=Password]{
	  width:80%;
	  padding:15px;
	  border:2px solid #ccc;
	  border-radius:10px;
	  resize:vertical;
  
  label {
    padding: 12px 12px 12px 0;
    display: inline-block;

  }

input[type=text]{
width:40%;
margin:20px;
border:2px solid gray;
height:30px;
border-redius:20px;
}
input{
	width:40%;
	border:2px solid gray;
	height:30px;
	border-redius:20px;
}
</style>
<form method="POST" action="action.php"align="center">				
<h1>Login</h1>
<div class="mb-3">
<label>Email</label><br>
<input value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" type="text" name="email" required class="form-control" /><br>
<small class='text-danger'><?php if(isset($errors['email'])) echo $errors['email']; ?></small><br>
</div>
				
<div class="mb-3">
<label>Password</label><br>
<input value="<?php if(isset($_POST['password'])) echo $_POST['password']; ?>" type="password" name="password" required class="form-control" /><br>
<small class='text-danger'><?php if(isset($errors['password'])) echo $errors['password']; ?></small><br>
</div>
		
<div class="mb-3"align="center">
<input type="submit" name="login" value="Login" class="btn btn-success" />
</div>
</form>
</body>
</head>
</html>