<?php 
$srvername = "localhost";
$username = "root";
$password = "";
$database = "krs";


$conn = new mysqli($srvername,$username,$password ,$database);


if ($conn -> connect_errno) {
 //echo "Failed" . $mysqli -> connect_error;
}else{
	// echo "Good";
}

date_default_timezone_set('Asia/Kolkata');

?>