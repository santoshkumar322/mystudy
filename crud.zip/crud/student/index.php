<?php
include('include/connection.php');
if(isset($_POST['submit'])){

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$alternate_no = $_POST['alternate_no'];
$date_of_birth = $_POST['date_of_birth'];
$gender = $_POST['gender'];
$nationality = $_POST['nationality'];
$address = $_POST['address'];
$follow_up_date = $_POST['follow_up_date'];
$follow_up_time = $_POST['follow_up_time'];
$follow_up_remarks = $_POST['follow_up_remarks'];
$intrested_course = $_POST['intrested_course'];
$intrested_country = $_POST['intrested_country'];
$Intake = $_POST['Intake'];
$martial_status = $_POST['martial_status'];
$source = $_POST['source'];
$apply_level = $_POST['apply_level'];
$status = $_POST['status'];
$highest_qualification = $_POST['highest_qualification'];
$test_given = $_POST['test_given'];
$meetings_date = $_POST['meetings_date'];
$meetings_time = $_POST['meetings_time'];
$meetings_remarks = $_POST['meetings_remarks'];
$remarks = $_POST['remarks'];
$select_branch = $_POST['select_branch'];
$date = date('d-m-Y h:i:s a');  



$inertquery = "INSERT INTO tbl_personal_details(first_name, last_name, email, mobile, alternate_no, date_of_birth, gender, nationality, address, follow_up_date, follow_up_time, follow_up_remarks, intrested_course, intrested_country, Intake, martial_status, source, apply_level, status, highest_qualification, test_given, meetings_date, meetings_time, meetings_remarks, remarks, select_branch,create_date, update_date)
VALUES ('$first_name','$last_name','$email','$mobile','$alternate_no','$date_of_birth','$gender','$nationality','$address','$follow_up_date','$follow_up_time','$follow_up_remarks','$intrested_course','$intrested_country','$Intake','$martial_status','$source','$apply_level','$status','$highest_qualification','$test_given','$meetings_date','$meetings_time','$meetings_remarks','$remarks','$select_branch','$date','$date')";

$result = $conn->query($inertquery);

$last_id = $conn->insert_id;

if($result == true){
	
$qualification = $_POST['qualification'];
$subjects_stream = $_POST['subjects_stream'];
$college_board = $_POST['college_board'];
$backlogs = $_POST['backlogs'];
$year_of_passing = $_POST['year_of_passing'];


foreach ($year_of_passing as $key => $value){


$qualificationquery = "INSERT INTO tbl_academic_details(last_id, qualification, subjects_stream, college_board, backlogs, year_of_passing,create_date, update_date) 
VALUES ('$last_id','$qualification[$key]','$subjects_stream[$key]','$college_board[$key]','$backlogs[$key]','$year_of_passing[$key]','$date','$date')";

$conn->query($qualificationquery);

}
?>
<script>
setTimeout(function() {
swal({
title: "Successfully Add",
text: "Thanks",
type: "success",
}).then(function() {
window.location.href = 'index.php';
});
}, 1000);
</script>

<?php }else{ ?>

<script>
setTimeout(function() {
swal({
title: "Insert Failed",
text: "Thanks",
type: "success",
}).then(function() {
window.location.href = 'index.php';
});
}, 1000);
</script>

<?php 
} 
} 
?>




<!DOCTYPE html>
<html lang="en">
<head>
<title>Bootstrap Card</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap_datepicker.min.css" />
<link href="css/classic.css" rel="stylesheet" />
<link href="css/classic.time.css" rel="stylesheet" />
<link href="css/classic.date.css" rel="stylesheet" />
<link rel="stylesheet" href="css/bootstrap-material-datetimepicker.min.css">


  
<style>
  
.card-header{
 padding: 5px 18px;
 background-color: #D8F2FF;
      
 }
  
 .input-group-span{
  background-color: #D8F2FF;   
 }
  
 .action_container p{
  margin:0px;
  }
  
  
 .sidebarbutton p a{
  background: #00004e;
  color: white;
  padding: 8px 18px;
  text-decoration: none;
  font-weight: 500;
  border-radius: 0;
 }
 
 .imagesmassg{
  position: fixed;
  width: 35px;
  width: 40px;
  bottom: 12px;
  right: 18px;
 }
  
</style>
  
</head>
<body> 

<section>
<div class="container-fluid">
<form class="form-group" action="" method="POST">      

<div class="row">
<div class="col-md-8">
<div class="card">
<div class="card-header "><h5>Personal Details</h5></div>
<div class="card-body">  
<div class="row">
<div class="col-md-4">
<label class="form-label" for="fname">First Name<span style="color:red;">*</span></label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-user" aria-hidden="true"></i></span></div>
<input class="form-control" type="text" name="first_name" id="fname" required placeholder="First Name">
</div>
</div>

<div class="col-md-4">
<label class="form-label" for="lname">Last Name</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-user" aria-hidden="true"></i></span></div>
<input class="form-control" type="text" name="last_name" id="lname" placeholder="Last Name">
</div>
</div>

<div class="col-md-4">
<label class="form-label" for="email">Email<span style="color:red;">*</span></label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-envelope" aria-hidden="true"></i></span></div>
<input class="form-control" type="email" name="email" id="email" required placeholder="Email">
</div>
</div>
</div>

<div class="row mt-3">
<div class="col-md-4">
<label class="form-label" for="number">Mobile<span style="color:red;">*</span></label>   
<div class="input-group">
<div  class="input-group-prepend"><span style="background: #efefef;" class="input-group-text input-group-span"><img src="images/india.png" alt="" width="16" height="16"> +91</span></div>
<input class="form-control" type="number" name="mobile" id="number" required placeholder="Mobile">
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="aname">Alternate No</label>   
<div class="input-group">
<div  class="input-group-prepend"><span style="background: #efefef;" class="input-group-text input-group-span"><img src="images/india.png" alt="" width="16" height="16"> +91</span></div>
<input class="form-control" type="number" name="alternate_no" id="aname" placeholder="Alternate No" >
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="date-birth">Date Of Birth</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-calendar" aria-hidden="true"></i></span></div>
<input class="form-control datepicker" type="text" name="date_of_birth" id="date-birth" placeholder="Date of Birth" >
</div>
</div>
</div>

<div class="row mt-3">
<div class="col-md-4">
<label class="form-label" for="gender">Gender</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-child" aria-hidden="true"></i></span></div>
<select class="form-control" name="gender" id="gender">
  <option value="">Select Gender</option>
  <option value="male">Male</option>
  <option value="female">Female</option>
  <option value="other">Other</option>
</select>
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="national">Nationality</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-flag" aria-hidden="true"></i></span></div>
<select class="form-control" name="nationality" id="national">
  <option value="">Select Country</option>
  <option value="India">India</option>
  <option value="Japan">Nepal</option>
  <option value="Japan">Bhutan</option>
  <option value="Japan">Srilanka</option>
  <option value="Japan">Pakistan</option>
 
</select>
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="address">Address</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-map-marker" aria-hidden="true"></i></span></div>
<input class="form-control" type="text" name="address" id="address" placeholder="Address">
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-md-4">
<div class="card">
<div class="card-header "><h5>Follow Up</h5></div>
<div class="card-body"> 
<div class="row">
<div class="col-md-12">
<label class="form-label" for="date">Follow Up Date</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-calendar" aria-hidden="true"></i></span></div>
<input class="form-control datepicker" type="text" name="follow_up_date" id="dob" placeholder="Follow Up Date" >
</div>
</div>

<div class="col-md-12 mt-3">
<label class="form-label" for="time">Follow Up Time</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-clock-o" aria-hidden="true"></i></span></div>
<input class="form-control timepickerrf" type="text" name="follow_up_time" id="time" placeholder="Follow Up Time">
</div>
</div>

<div class="col-md-12 mt-3">
<label class="form-label" for="remarks">Follow Up Remarks</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-comment" aria-hidden="true"></i></span></div>
<input class="form-control" type="text" name="follow_up_remarks" id="remarks" placeholder="Follow Up Remarks"  >
</div>
</div>

</div>
</div>
</div>

</div>
</div>

<div class="row mt-5">
<div class="col-md-8">
<div class="card">
<div class="card-header "><h5>Other Details </h5></div>

<div class="card-body">
 
<div class="row">
<div class="col-md-4">
<label class="form-label" for="course">Interested Course </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-graduation-cap" aria-hidden="true"></i></span></div>
<input class="form-control" type="text" name="intrested_course" id="course" placeholder="Intrested Course" >
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="income">Interested Country </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-flag" aria-hidden="true"></i></span></div>
<select class="form-control" name="intrested_country" id="country">
 <option value="">Select Country</option>
  <option value="India">India</option>
  <option value="Japan">Nepal</option>
  <option value="Japan">Bhutan</option>
  <option value="Japan">Srilanka</option>
  <option value="Japan">Pakistan</option>
</select>
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="intake">Intake</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-calendar" aria-hidden="true"></i></span></div>
<input class="form-control" type="text" name="Intake" id="intake" placeholder="Intake"  >
</div>
</div>
</div>

<div class="row mt-3">
<div class="col-md-4">
<label class="form-label" for="number">Marital Status</label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-venus-mars" aria-hidden="true"></i></span></div>
<select class="form-control" name="martial_status" id="martial">
  <option value="">Marital Status</option>
  <option value="married">Married</option>
  <option value="unmarried">Unmarried</option>
</select>
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="source">Source </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><img src="images/wifiicon.png" alt="" width="14" height="14"></span></div>
<select class="form-control" name="source" id="source">
  <option value="">Select Source</option>
  <option value="Source A">Source A</option>
  <option value="Source B">Source B</option>
  <option value="Source C">Source C</option>
</select>
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="level">Apply Level </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-graduation-cap" aria-hidden="true"></i></span></div>
<select class="form-control" name="apply_level" id="level">
  <option value="">Select Level</option>
  <option value="Level A">Level A</option>
  <option value="Level B">Level B</option>
  <option value="Level C">Level C</option>
</select>
</div>
</div>
</div>


<div class="row mt-3">
<div class="col-md-4">
<label class="form-label" for="status">Status </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-list" aria-hidden="true"></i>
</span></div>
<select class="form-control" name="status" id="status">
  <option value="">New Enquiry</option>
  <option value="Active">Active</option>
  <option value="Inactive">Inactive</option>
</select>
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="qualification ">Highest Qualification </label>   
<div class="input-group">
<!--<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-code-fork" aria-hidden="true"></i></span></div>-->
<input class="form-control" type="text" name="highest_qualification" id="qualification" placeholder="Highest Qualification"  >
</div>
</div>


<div class="col-md-4">
<label class="form-label" for="scoremark">Test Given (Score/Marks) </label>   
<div class="input-group">
<!--<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-sliders" aria-hidden="true"></i></span></div>-->
<input class="form-control" type="text" name="test_given" id="scoremark" placeholder="Test Given"  >
</div>
</div>
</div>



<div class="row mt-3">
<div class="col-md-12">
<label class="form-label" for="status">Remarks </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-list" aria-hidden="true"></i></span></div>
<input class="form-control" type="text" name="remarks" id="status" placeholder="Remarks">
</div>
</div>
</div>

</div>

</div>

</div>
<div class="col-md-4">
           
<div class="card">
<div class="card-header "><h5>Meetings</h5></div>

<div class="card-body"> 

<div class="row">
<div class="col-md-12">
<label class="form-label" for="mdate">Meetings Date </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-calendar" aria-hidden="true"></i></span></div>
<input class="form-control datepicker" type="date" name="meetings_date" id="" placeholder="Meetings Date" >
</div>
</div>

<div class="col-md-12 mt-3">
<label class="form-label" for="mtime">Meetings Time </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-clock-o" aria-hidden="true"></i></span></div>
<input class="form-control timepickerfdgdsfg" type="text" name="meetings_time" id="Start_time" placeholder="Meetings Time"  >
</div>
</div>

<div class="col-md-12 mt-3">
<label class="form-label" for="mremarks">Meetings Remarks </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-comment" aria-hidden="true"></i></span></div>
<input class="form-control" type="text" name="meetings_remarks" id="mremarks" placeholder="Meetings Remarks" >
</div>
</div>

</div>

</div>
</div>

           
<div class="card mt-3">
<div class="card-header "><h5>Assign Students</h5></div>

<div class="card-body"> 

<div class="row">
<div class="col-md-12">
<label class="form-label" for="branch">Select Branch </label>   
<div class="input-group">
<div class="input-group-prepend"><span class="input-group-text input-group-span"><i class="fa fa-code-fork" aria-hidden="true"></i></span></div>
<select class="form-control" name="select_branch" id="branch">
  <option value="">Select Branch</option>
  <option value="Branch A">Branch A</option>
  <option value="Branch B">Branch B</option>
  <option value="Branch C">Branch C</option>
</select>
</div>
</div>


</div>



</div>
</div>

</div>
</div>


<div class="mt-3 licenceform1 details"><div class="card-header "><h5>Academic Details </h5></div></div>

<!--<div class="row clearfix"><div class="col-md-12 text-right mt-3">
<p id="add_row" class="btn btn-primary"><i class="fa fa-plus"></i></p>
<p id='delete_row' class="btn btn-danger"><i class="fa fa-minus"></i></p>
</div>
</div>-->

<div class="row clearfix">
<div class="col-md-12">
<div class="table-responsive">
<table class="table table-bordered table-hover" id="tab_logic">
<thead>
<tr>
<th class="text-center">Qualification</th>
<th class="text-center">Subjects/Stream</th>
<th class="text-center">College/Board</th>
<th class="text-center"> Backlogs</th>
<th class="text-center">Year of Passing </th>
<th><div class="action_container"><p onclick="create_tr('table_body')" class="btn btn-success"><i class="fa fa-plus"></i></p></div></th>
</tr>
</thead>
<tbody id="table_body">
<tr id=''>
<td><select class="form-control"   id="dropdown" name="qualification[]" step="0" min="0">
<option value="">Select Qualification</option>
<option value="Matrick">Matrick</option>
<option value="Intermediate">Intermediate</option>
<option value="BCA">BCA</option>
<option value="MCA">MCA</option>
</select>
</td>
<td><input type="text"  name='subjects_stream[]' class="form-control" placeholder="Subjects/Stream" /></td>
<td><input type="text" name='college_board[]' class="form-control" placeholder="College/Board"  /></td>
<td><input type="text" name='backlogs[]' class="form-control" step="0" min="0" placeholder="College/Board"/></td>
<td><input type="text" name='year_of_passing[]' class="form-control" step="0" min="0" placeholder="Year of Passing"/></td>
<td><div class="action_container"><p onclick="remove_tr(this)" class="btn btn-danger"><i class="fa fa-minus"></i></p></div></td>
</tr>

<!--<tr id='addr1'></tr>-->
</tbody>
</table>
</div>
</div>
</div>

<div class="row">
<div class="col-md-12">
<div class="octf-header-module">
<div class="btn-cta">
<button type="submit" name="submit" class="btn btn-success">Save</button>
</div>
</div>
</div>
</div>



</form>
</div>
</section>

<section>
   <div class="sidebarbutton">
   <p><a href="#">Quick Enquiry</a></p>
   <p><a href="#">Send Enquiry Link</a></p>
   </div>
</section>

<div>
    <a href="#"><img class="imagesmassg" src="images/messageicon.png"></a>
</div>


</body>
</html>

  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="js/sweetalert2.all.min.js"></script>
  
  <script src="js/legacy.js"></script>
  <script src="js/picker.js"></script>
  <script src="js/picker.time.js"></script>
  <script src="js/picker.date.js"></script>
  <script src="js/bootstrap-material-datetimepicker.min.js"></script>
  <script src="js/moment.min.js"></script>

<script>
$('.datepicker').pickadate({
selectMonths: true,
selectYears: true
}),
$('.timepicker').pickatime()
</script>
<script>
$(function () {
$('.Start_Date').bootstrapMaterialDatePicker({
format: 'DD-MM-YYYY hh:mm:ss A',
minDate:new Date(),
startDate: "<?php echo date('d-m-Y');?>",
});
			
$('.filter_Date').bootstrapMaterialDatePicker({
format: 'DD-MM-YYYY hh:mm:ss A',
});
			
$('#date').bootstrapMaterialDatePicker({
time: false
});
$('#time').bootstrapMaterialDatePicker({
date: false,
format: 'HH:mm'
});
});
</script>
<script src="js/bootstrap_datepicker.min.js"></script>


<script>
    
function create_tr(table_id) {
let table_body = document.getElementById(table_id),
first_tr = table_body.firstElementChild;
tr_clone = first_tr.cloneNode(true);

table_body.append(tr_clone);

clean_first_tr(table_body.firstElementChild);
}

function clean_first_tr(firstTr) {
let children = firstTr.children;

children = Array.isArray(children) ? children : Object.values(children);
children.forEach((x) => {
if (x !== firstTr.lastElementChild) {
x.firstElementChild.value = "";
}
});
}

function remove_tr(This) {
if (This.closest("tbody").childElementCount == 1) {
alert("You Don't have Permission to Delete This ?");
} else {
This.closest("tr").remove();
}
}
   
</script>

<script>
$(document).ready(function(){
$("#basic-form").validate();
});
</script>