<?php
include'connect.php';
$id = $_GET['updateid'];
$sql = "select * from add_data where id=$id";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);

$name=$row['name'];
$email=$row['email'];
$mobile=$row['mobile'];
$gender=$row['gender'];
$address=$row['address'];

if(isset($_POST['submit'])){	
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$gender=$_POST['gender'];
	$address=$_POST['address'];
	
	$sql="update add_data set id=$id,name='$name',email='$email',mobile='$mobile',gender='$gender',address='$address'
	where id = $id";
	$result = mysqli_query($con,$sql);
	if($result){
		
	echo "updated successfully";
	
    header('location:display.php');
	
	}else{
		
	die(mysql_error($con));
	
	}
}
?>
<!doctype html>
<html lang="en">
<head>
<!--Required meta tags-->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1, shrink-to-fit=no">
<!--Bootstrap css-->
<link rel="stylesheet" href="https://maxcdn.Bootstrapcdn.com/Bootstrap/4.0.0/css/Bootstrap.mincss">
<title>crud operation</title>
</head>

<body>
<div class="container my-5">
<form method="post">
<div class="form-group">
<label>Name</label><br>
<input type="text"class="form-control" placeholder="Enter your name" name="name"autocomplete="off" value=<?php echo $name;?>>
</div>
<div class="form-group">
<label>Email</label><br>
<input type="email" class="form-control" placeholder="Enter your email" name="email" autocomplete="off" value=<?php echo $email;?>>
</div>
<div class="form-group">
<label>Mobile</label><br>
<input type="mobile" class="form-control"placeholder="Enter your mobile"name="mobile" autocomplete="off" value=<?php echo $mobile;?>>
</div>
<div class="form-group">
<label>Gender</label><br>
<input type="text" class="form-control"placeholder="Enter your gender"name="gender" autocomplete="off" value=<?php echo $gender;?>>
</div><br>
<div class="form-group">
<label>Address</label><br>
<input type="address" class="form-control"placeholder="Enter your address"name="address" autocomplete="off" value=<?php echo $address;?>>
</div>
<button type="submit" class="btn btn-primary" name="submit">Update</button>
</form>
</div>
</body>