<?php
include'connect.php';
if(isset($_POST['submit'])){
	
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$gender=$_POST['gender'];
	$address=$_POST['address'];
	//$password=$_POST['password'];
	
	//$sql="INSERT INTO add_data(name,email,mobile,password)
	$sql="INSERT INTO add_data(name,email,mobile,gender,address)
	values('$name','$email','$mobile','$gender','$address')";
	
	$result=mysqli_query($con,$sql);
	if($result){
  // echo "Submited successfully";
   // header('location:display.php');
	}else{
	die(mysql_error($con));

}
}

?>
<!Doctype html>
<html lang="en">
<head>
<!--Required meta tags-->
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
<!--Bootstrap css-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<title>Crud opration</title>
</head>
<style>
h1{
color:darkblue;
}
</style>
<body>
<div class="container">
<button class="btn btn-primary my-1">
<a href= "display.php" class = "text-light">Display User</a>
</button>
</div>
<h1 align="center">User Application Form</h1>
<div class="container my-5">
<form method="post">
<div class="form-group">
<label>Name</label>
<input type="text"class="form-control" placeholder="Enter your name" name="name" autocomplete="off" required>
</div>

<div class="form-group">
<label>Emil</label>
<input type="email"class="form-control" placeholder="Enter your email" name="email" autocomplete="off" required>
</div>
<div class="form-group">
<label>Mobile</label>
<input type="text"class="form-control" placeholder="Enter your mobile number" name="mobile" autocomplete="off" required>
</div>
<!--<div class="form-group">
<label>password</label>
<input type="text"class="form-control" placeholder="Enter your password" name="password" autocomplete="off" required>
</div>-->
<div class="form-group">
<label>Gender:</label><br>
<label for = "Male">Male</label required>
<input type="radio" name="gender" value="Male">
<label for = "female">Female</label required>
<input type="radio" name="gender" value="femel">
<label for = "other">Other</label required>
<input type="radio" name="gender" value="other">
</div>
<div class="form-group">
<label>Address</label>
<input type="text"class="form-control" placeholder="address" name="address" autocomplete="off" required>
</div>
<button type="submit" class="btn btn-primary"name="submit">Submit</button>
</form>
</div>
</body>
</html>
<?php
/*
include'connect.php';

if(isset($_POST['submit'])){
	
	
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$password=$_POST['password'];
	
	$sql="INSERT INTO crud(name,email,mobile,password)
	values('$name','$email','$mobile','$password')";
	
	$result=mysqli_query($con,$sql);
	if($result){
		//echo "Data inserted successfully";
    header('location:display.php');
	}else{
		die(mysql_error($con));
	}
}

*/
?>