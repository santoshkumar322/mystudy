<?php
print_r($_POST);

$email='';
$pass="";
$sql="";
return true; //false;
echo 'coming to those page or not';


?>