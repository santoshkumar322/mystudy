<?php //include("user.php"); ?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="user.php">Home</a></li>
          <li><a href="user_login.php">Login</li>
        </ol>
        <h2>Login</h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page">
      <div class="container" data-aos="fade-up">

      <?php
            if(isset($_COOKIE['success']))
            {
                echo "<p id='msg' class='alert alert-success'>".$_COOKIE['success']."</p>";
            }
            if(isset($_COOKIE['error']))
            {
                echo "<p id='msg' class='alert alert-danger'>".$_COOKIE['error']."</p>";
            }

            $errors = [];
            function cleanData($str)
            {
                return addslashes(strip_tags(trim($str)));
            }
            if(isset($_POST['login']))
            {
                $email = (isset($_POST['email'])) ? cleanData($_POST['email']) : '';
                $pass = (isset($_POST['password'])) ? cleanData($_POST['password']) : '';
                // validation
                
                // Email validation;
                if($email === "")
                {
                    $errors['email'] = "Email is Required";
                }
                else
                {
                    if(!filter_var($email, FILTER_VALIDATE_EMAIL))
                    {
                        $errors['email'] = "Email a valid email";
                    }
                }
                
                if($pass === "")
                {
                    $errors['password'] = "Password is Required";
                }
                
                if(count($errors) === 0)
                {
                    $result = mysqli_query($con, "select username, password,token, status from users where email='$email'");
                    if(mysqli_num_rows($result)===1)
                    {
                        $row = mysqli_fetch_assoc($result);
                        //print_r($row);
                        if(password_verify($pass, $row['password']))
                        {
                            if($row['status'] === "active")
                            {
                                $_SESSION['userlogin'] = $row['token'];
                                $_SESSION['username'] = $row['username'];
                                header("Location:home.php");
                            }
                            else
                            {
                                echo "<p>Please activate your account</p>";
                            }
                        }
                        else
                        {
                            echo "<p class='alert alert-danger'>Password does not matched</p>";
                        }
                        
                    }
                    else
                    {
                        echo "<p class='alert alert-danger'>Wrong email entered</p>";
                    }
                }
            }
				
        ?>

      <form method="POST" action="">
				
				<div class="mb-3">
					<label>Email</label>
					<input value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" type="text" name="email" class="form-control" />
					<small class='text-danger'><?php if(isset($errors['email'])) echo $errors['email']; ?></small>
				</div><br>
				
				<div class="mb-3">
					<label>Password</label>
					<input value="<?php if(isset($_POST['password'])) echo $_POST['password']; ?>" type="password" name="password" class="form-control" />
					<small class='text-danger'><?php if(isset($errors['password'])) echo $errors['password']; ?></small>
				</div>
		
			<div class="mb-3">
				<input type="submit" name="login" value="Login" class="btn btn-success" />
                <p><a href="forgot.php">Forgot Password?</a></p>
                <p><a href="register.php">Create New Account</a></p>
			</div>
			</form>
      </div>
    </section>

  </main><!-- End #main -->

  <?php 
   // include("footer.php"); 
  ?>