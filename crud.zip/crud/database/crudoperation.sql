-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 05, 2025 at 07:50 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crudoperation`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_data`
--

CREATE TABLE `add_data` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` text NOT NULL,
  `gender` text NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `add_data`
--

INSERT INTO `add_data` (`id`, `name`, `email`, `mobile`, `gender`, `address`) VALUES
(3, 'sarda', 'sarda@123gmail.com', '8879803562', 'femel', 'MAHAMMADPUR'),
(4, 'Rakesh', 'rakesh@123gmail.com', '8879803562', 'Male', 'MAHAMMADPUR PO GORIAKOTHI DISTRICT-SIWAN PIN 841434'),
(5, 'Rakesh', 'rakesh@123gmail.com', '8879803562', 'Male', 'MAHAMMADPUR PO GORIAKOTHI DISTRICT-SIWAN PIN 841434'),
(6, 'Rakesh', 'rakesh@123gmail.com', '8879803562', 'Male', 'MAHAMMADPUR PO GORIAKOTHI DISTRICT-SIWAN PIN 841434'),
(7, 'Rakesh', 'rakesh@123gmail.com', '8879803562', 'Male', 'MAHAMMADPUR PO GORIAKOTHI DISTRICT-SIWAN PIN 841434'),
(8, 'Namita', 'namita@123gmail.com', '9587639200', 'femel', 'jbp'),
(9, 'santosh kumar', 'santoshkr322@gmail.com', '8506089215', 'Male', 'VILL- MAHAMMADPUR PO GOREYAKOTHO DIST-SIWAN BIHAR PIN -841434'),
(10, 'santosh kumar', 'santoshkr322@gmail.com', '8506089215', 'Male', 'VILL- MAHAMMADPUR PO GOREYAKOTHO DIST-SIWAN BIHAR PIN -841434'),
(11, 'priyanka', 'priyanks.k@netxcell.com', '7856903201', 'femel', 'mumbai'),
(12, 'Ashwini s', 'ashwini.s@gmail.com', '9862356245', 'femel', 'bangloru');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `Id` int(11) NOT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `ParentId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`Id`, `CreatedDate`, `Name`, `ParentId`) VALUES
(1, NULL, 'anup', NULL),
(3, NULL, 'Abhijit', NULL),
(4, NULL, 'Albiterto', 3),
(5, NULL, 'Bala', 4),
(6, NULL, 'Sadashiv', 4),
(8, NULL, 'sid', 3),
(9, NULL, 'raghven', NULL),
(11, NULL, 'Arwind', NULL),
(12, NULL, 'david', NULL),
(13, NULL, '', 3),
(14, NULL, '', 4),
(15, NULL, 'albrito', 3),
(16, NULL, 'sarvesh', NULL),
(17, NULL, 'albrito', 3),
(18, NULL, 'albrito', 3),
(21, NULL, 'manjiri', NULL),
(23, NULL, '', NULL),
(25, NULL, 'abc', 11),
(26, NULL, 'Nameeta patel', 11),
(27, NULL, 'Ashwini', 1),
(28, NULL, 'Ashwini', 12),
(29, NULL, 'Ashwini', 17);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_data`
--
ALTER TABLE `add_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `ParentId` (`ParentId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_data`
--
ALTER TABLE `add_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `members`
--
ALTER TABLE `members`
  ADD CONSTRAINT `members_ibfk_1` FOREIGN KEY (`ParentId`) REFERENCES `members` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
