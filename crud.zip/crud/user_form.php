<html>
<head>
<?php
session_start();
//session_unset();
//session_destroy();
//header("location:admin_login.php");
//exit;

//include_once"database/connection.php";

//header("location: admin_login.php");


?>
<title>add user registration form</title>
<style>
h1{
	color:darkblue;
}
*{
	margin:0;
	box-sizeing: border-box;
}
.container{
	width: 80%;
	margin:0px auto;
	background-color: #efefef;
	padding: 20px
}
.formgroup{
	padding: 10px 0px;
	border-radius: 5px;
}
.formcontrol{
	width: 100%;
	border: 2px solid #333;
	height: 34px;
	border-radius: 5px;
}
.error{
	color: red;
}
.successmsg{
background-color: yellowgreen;
padding: 10px;
text-align:center;
color: #fff;
border-radius: 10px;
}
			
.errormsg{
background-color: tomato;
padding: 10px;
text-align:center;
color: #fff;
border-radius: 10px;
}	
  input[type=submit] {
    background-color: #04AA6D;
	width:10%;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    float:center;
  }
  
  input[type=submit]:hover {
    background-color: #45a049;
  }		
</style>

</head>
<script src="jquery.js"></script>  
<script src="bootstrap-datepicker.js"></script>
<script src="vendor/bootstrap/js/bootstrap-datepicker.js"></script>

<link href="bootstrap-datepicker.css" rel="stylesheet">
<body>
<div class="container">
<h1>Add user registration form</h1>
<?php 
 
/* 
session_start(); 

echo "<script>alert('Logged Out as Admin');</script>";
unset($_SESSION['ladm_val']);
		 
echo "<script>location.href='login.php';</script>";
    
*/	  
//include_once"database/connection.php";
//$errors = [];
if(isset($_POST['submit']))
{
//form collected and sanitized
/*
$name = isset($_POST['name'])? cleanData($_POST['name']) : '';
$email = isset($_POST['email'])? cleanData($_POST['email']) : '';
$mobile = isset($_POST['mobile'])? cleanData($_POST['mobile']) : '';
$gender = isset($_POST['gender'])? cleanData($_POST['gender']) : '';
$dob = isset($_POST['dob'])? cleanData($_POST['dob']) : '';
$state = isset($_POST['state'])? cleanData($_POST['state']) : '';
$address = isset($_POST['address'])? cleanData($_POST['address']) : '';
*/
$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$state = $_POST['state'];
$address = $_POST['address'];

 $sql = "INSERT INTO user_info(name,email,mobile,gender,dob,state,address)
	 VALUES('$name','$email','$mobile','$gender','$dob','$state,'$address')";
	 if(mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

//validate the form data
//form validation
/*
if($name === "")
{
$errors['name'] = "name is required";
}
	*/
?>
<form method="POST"action="" onsubmit=""> 
<div class="formgroup">
<label for = "name">Name:<font style="color:red;">*</font></label>
<input value="<?php if(isset($_POST['name'])) echo $_POST['name'];?>" type="text" name="name" placeholder="Enter name" required class="formcontrol"/>
<small class="error"><?php if(isset($errors['Name'])) echo $errors['name'];?></small>
</div>

<div class="formgroup">
<label for = "email">Email:<font style="color:red;">*</font></label>
<input value="<?php if(isset($_errors['email'])) echo $_POST['email'];?>" type="text" name="email" placeholder="Enter email" required class="formcontrol"/>
<small class="error"><?php if(isset($error['email'])) echo $error['email'];?></small>
</div>
<div class="formgroup">
<label for = "mobile">Mobile:<font style="color:red;">*</font></label>
<input value="<?php if(isset($_POST['mobile']))echo $_POST['mobile'];?>" type="text" name="mobile" placeholder="Enter mobile" required class="formcontrol"/>
<small class="error"><?php if(isset($error['mobile']))echo $error['Mobile'];?></small>
</div>
<div class="formgroup">
<label for = "gender">Gender:<font style="color:red;">*</font></label><br>
<label for = "Male">Male:</label required>
<input type="radio" name="gender" value="Male">
<label for = "female">Female:</label required>
<input type="radio" name="gender" value="femel">
</div>
 <div class="formgroup">
 <label for="dob">Date Of birth:<font style="color:red;">*</font></label></br>
 <input name="dob" type="Date" id="dob" class="formgroup" autocomplete="off" title="Please select DOb " required>
 </div>
<div class ="formgroup">
<label for = "state">state:<font style="color:red;">*</font></label><br>
<select class = "formgroup">
<option value = "select">select</option required>
<option value = "bihar">bihar</option>
<option value = "uttar pradesh">uttar pradesh</option>
<option value = "jharkhand">jharkhand</option>
<option value = "west bengal">west bengal</option>
<option value = "manipur">manipur</option>
<option value = "mizoram">mizoram</option>
<option value = "rajsthan">rajasthan</option>
<option value = "chatishghar">chatishghar</option>
<option value = "andhra pradesh">andhra pradesh</option>
<option value = "hariyana">hariyana</option>
<option value = "telangana">telangana</option>
<option value = "utrakhand">utrakhand</option>
<option value = "maharasthra">maharasthra</option>
<option value = "west bengal">west bengal</option>
<option value = "goa">goa</option>
<option value = "meghalaya">meghalaya</option>
<option value = "odisha">odisha</option>
<option value = "gujarat">gujarat</option>
<option value = "madhya pradesh">madhya pradesh</option>
<option value = "himachal pradesh">himachal pradesh</option>
<option value = "kerla">kerla</option>
<option value = "delhi">delhi</option>
<option value = "jamu&kasmir">jamu&kasmir</option>
</select>
</div>

<label for = "address">Address:</label>
<input value="" Name="address" class="formcontrol"/>
<div class="formgroup">
<input type="submit" name="submit" class="btn" value="submit"/>
</div>
</form>
</div>

</div>
</body>
</html>