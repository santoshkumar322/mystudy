<?php
require_once('Member.php');

$member = new Member();
$membersList = $member->getMembersTree();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Members Tree</title>
</head>
<body>
    <ul>
        <?php echo $membersList; ?>
    </ul>
   <button onclick="openPopup()">Add Member</button>

    <div id="popup" style="display: none;">
        <form id="addMemberForm">
            <label for="parent">Parent:</label>
            <select id="parent" name="parent"required>
			<option value="">Select</option>
                <?php echo $member->getMembersDropdown(); ?>
            </select><br>

            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required><br>
             <button type="button" onclick="close()">close</button>
            <button type="button" onclick="saveChanges()">Save Changes</button>
		
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <script src="script.js"></script>
</body>
</html>
