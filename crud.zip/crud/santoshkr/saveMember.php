<?php
require_once('Member.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $member = new Member();
    $parent = $_POST['parent'];
    $name = $_POST['name'];
	$stmt = $member->pdo->prepare("INSERT INTO Members ( Name, ParentId) VALUES ( :name, :parent)");
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':parent', $parent, PDO::PARAM_INT);
    $stmt->execute();

    // Return the newly created entry in HTML format
    echo "<li>{$name}</li>";
}
?>
