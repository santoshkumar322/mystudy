<?php

class Member {
    public $pdo;

    public function __construct() {
        $this->pdo = new PDO("mysql:host=localhost;dbname=crudoperation", "root", "", array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    }

    public function getMembersTree($parentId = 0) {
        $stmt = $this->pdo->prepare("SELECT * FROM Members WHERE ParentId = :parentId");
        $stmt->bindParam(':parentId', $parentId, PDO::PARAM_INT);
        $stmt->execute();

        $result = "<ul>";
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result .= "<li>{$row['Name']} {$this->getMembersTree($row['Id'])}</li>";
        }
        $result .= "</ul>";

        return $result;
    }

    public function getMembersDropdown() {
        $stmt = $this->pdo->query("SELECT * FROM Members");
        $result = "";
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result .= "<option value='{$row['Id']}'>{$row['Name']}</option>";
        }
        return $result;
    }
}
?>
