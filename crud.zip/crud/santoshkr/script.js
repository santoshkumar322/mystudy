function openPopup() {
    $.fancybox.open({
        src: '#popup',
        type: 'inline'
    });
}

function saveChanges() {
    var form = $('#addMemberForm');
    
    $.ajax({
        type: 'POST',
        url: 'saveMember.php',
        data: form.serialize(),
        success: function(response) {
            $.fancybox.close();
            // Append the new entry to the existing tree structure using jQuery append
            $('ul').append(response);
        }
    });
}
