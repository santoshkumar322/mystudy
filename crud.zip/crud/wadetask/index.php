<?php
//include'crud/connect.php';
if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$photo1 = $_POST['photo1'];
	$photo2 = $_POST['photo2'];
	
	$sql = "INSERT INTO user_data(name,email,mobile,photo1,photo2)VALUES('$name','$email','$mobile','$photo1',$photo2')";
	if(mysqli_query($con, $sql)){
		
		echo "New record created successfully !";
		
	}else{
		echo "Error: " . $sql . "" . mysql_error($con);
	}
	mysqli_close($con);
}
?>
<html>
<head>
<title>User details form</title>
<style>
h1{
	color:darkblue;
}
*{
	margin:0;
	box-sizeing: border-box;
}
.container{
	width: 50%;
	margin:0px auto;
	background-color: #efefef;
	padding: 20px
}
.formgroup{
	padding: 10px 0px;
	border-radius: 5px;
}
.formcontrol{
	width: 100%;
	border: 2px solid #333;
	height: 34px;
	border-radius: 5px;
}
.error{
	color: red;
}
.successmsg{
background-color: yellowgreen;
padding: 10px;
text-align:center;
color: #fff;
border-radius: 10px;
}
			
.errormsg{
background-color: tomato;
padding: 10px;
text-align:center;
color: #fff;
border-radius: 10px;
}	
  input[type=submit] {
    background-color: #04AA6D;
	width:30%;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    float:center;
  }
  
  input[type=submit]:hover {
    background-color: #45a049;
  }		
</style>

</head>
<!--<script src="jquery.js"></script>  
<script src="bootstrap-datepicker.js"></script>
<script src="vendor/bootstrap/js/bootstrap-datepicker.js"></script>

<link href="bootstrap-datepicker.css" rel="stylesheet">-->
<body>
<div class="container">
<h1 align="center">User details form</h1>
<?php
if(isset($_POST['Submit']))
{
	if($_FILES["image"]["tmp_name"]){
			$target_file = 'images/'.$_FILES["image"]["name"];
			move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
	}
	?>
	<table style="width: 500px; border: 1px solid;">
  
  <tr>
    <td>Name</td>
    <td><?php echo $_POST['name'];?></td>
  </tr>
	<tr>
    <td>Email</td>
    <td><?php echo $_POST['email'];?></td>
  </tr>
  <tr>
    <td>Mobile</td>
    <td><?php echo $_POST['mobile'];?></td>
  </tr>
  <tr>
    <td>Photo 1</td>
    <td>
	<?php
	if($target_file)
	{
		echo '<img src="'.$target_file.'">';
	}	?>
	</td>
  </tr>
  <tr>
    <td>Photo 2</td>
    <td><?php echo $_FILES["pdf"]["name"];?></td>
  </tr>
</table>
	
	<?php
}
//print_r($_FILES); 
?>

<form method="POST"action="" onsubmit="" enctype="multipart/form-data"> 
<div class="formgroup">
<label for = "name">Name:<font style="color:red;">*</font></label>
<input value="<?php if(isset($_POST['name'])) echo $_POST['name'];?>" type="text" name="name" placeholder="Enter name" required class="formcontrol"/>
<small class="error"><?php if(isset($errors['Name'])) echo $errors['name'];?></small>
</div>

<div class="formgroup">
<label for = "email">Email:<font style="color:red;">*</font></label>
<input value="<?php if(isset($_errors['email'])) echo $_POST['email'];?>" type="text" name="email" placeholder="Enter email" required class="formcontrol"/>
<small class="error"><?php if(isset($error['email'])) echo $error['email'];?></small>
</div>
<div class="formgroup">
<label for = "mobile">Mobile:<font style="color:red;">*</font></label>
<input value="<?php if(isset($_POST['mobile']))echo $_POST['mobile'];?>" type="text" name="mobile" placeholder="Enter mobile" required class="formcontrol"/>
<small class="error"><?php if(isset($error['mobile']))echo $error['Mobile'];?></small>
</div>
<div>
 <label for="image">Upload Image (jpg, jpeg, png):</label><br>
    <input type="file" id="image" name="image" accept="image/jpeg, image/png" required><br>

    <label for="pdf">Upload PDF:</label><br>
    <input type="file" id="pdf" name="pdf" accept="application/pdf" required><br><br>
</div>
<div class="formgroup">
<input type="Submit" name="Submit" class="btn" value="Submit"/>

</div>
</form>
</div>

</div>
</body>
</html>