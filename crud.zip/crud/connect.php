<?php
$server = "localhost";
$user = "root";
$password = "";
$database = "crudoperation";
//$database = "crudnew";
$con = mysqli_connect($server,$user,$password,$database);

if($con){
	
//echo "connection success";

}else{
	
die(mysqli_error($con));
	
echo "sorry please check connection";
}
	
/*

$con=new mysqli('localhost','root','','crudoperation');
if($con){
echo "connection successfully";
}else{
	die(mysqli_error($con));
	echo "sorry!";
}
*/
?>