<html>
<head>
<?php	 
if(isset($_POST['login']))
{
session_start();
	$email=$_POST['email'];
	if(empty($_POST['email']) || empty($_POST['Password']))
	{
 header("location: user.php?Empty=please fill in the Blanks");	
	
}else{
	
$firstLogincheck_id=mysqli_fetch_row(mysqli_query($con, "SELECT ID FROM crud where id=$id"));
if($firstLogincheck_id[0]==0){
	echo "<script>window.location='logout.php';('Invalid login id !');</script>";
}
else{
	
	//firstLogincheck=mysqli_fetch_row(mysqli_query($con, "SELECT Password from crud wherwe id=$id"));
	 // echo $firstLoginCheck[0];
	 if($firstLogincheck[0]==0){
	echo "hii";
	header("location:resetFirstLogin.php?id=$id");
        }
        else{
            // echo "<br>select * from login where login_id='".$_POST['email']."' and  password='".$_POST['Password']."'";
            $sql1="select * from login where login_id=".$_POST['email']." and password=md5('".$_POST['Password']."')";
            $data=mysqli_query($con,$sql1);        
            $row=mysqli_fetch_assoc($data);
            if($row)
            {
                $_SESSION['User']=$row['login_id'];
                header("location:user.php");
            }
            else
            {
           $message="<span class='alert alert-danger form-control' style='text-align:center'><b>Please Enter Correct User Name and Password</b></span>";
        }
		}
    }
    }

} 

   ?>
	
	
<?php
	
//header("location: user.php");

//echo "<script>alert('Logged Out Admin');</script>";

 //header("location: user.php");
 
 ?>
<body>
<style>
h1{
	color:darkblue;
}
  input[type=submit] {
    background-color: #04AA6D;
	width:30%;
    color: white;
    padding: 15px 20px;
    border: none;
    border-radius: 30px;
    cursor: pointer;
    float:center;
  }
  
  input[type=login]:hover {
    background-color: #45a049;
  }
form{

	border-radius:140px;
	width: 50%;
	margin:100px auto;
	background-color: #ccc;
	padding: 25px;

}
  input[type=text]{
    width: 80%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 10px;
    resize: vertical;
	
  }
  input[type=Password]{
	  width:80%;
	  padding:12px;
	  border:2px solid #ccc;
	  border-radius:10px;
	  resize:vertical;
  }
  label {
    padding: 12px 12px 12px 0;
    display: inline-block;

  }

input[type=text]{
width:40%;
margin:20px;
border:2px solid gray;
height:40px;
border-redius:20px;
}
input{
	width:50%;
	border:2px solid gray;
	height:40px;
	border-redius:20px;
}


</style>
<form method="POST" action=""align="center">				
<h1>Admin login</h1>
<div class="mb-3">
<label>Email</label><br>
<input value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" type="text" name="email" required class="form-control" /><br>
<small class='text-danger'><?php if(isset($errors['email'])) echo $errors['email']; ?></small><br>
</div>
				
<div class="mb-3">
<label>Password</label><br>
<input value="<?php if(isset($_POST['password'])) echo $_POST['password']; ?>" type="password" name="password" required class="form-control" /><br>
<small class='text-danger'><?php if(isset($errors['password'])) echo $errors['password']; ?></small><br>
</div>
		
<div class="mb-3"align="center">
<input type="submit" name="login" value="login" class="btn btn-success" />
</div>
</form>
</body>
</head>
</html>